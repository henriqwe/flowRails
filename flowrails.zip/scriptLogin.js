formLogin.addEventListener('submit', (e) => {
    e.preventDefault()
    window.location.href = 'dashboard.html';
})